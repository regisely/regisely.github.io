%Assigment6
%Marius del Giudice Rodriguez
%     The following functional forms are used:
%     U(c,h,n) = log c + a n log(l-h)
%     F(k,h) = exp(z)h*k^theta * n^(1-theta)
%     A(z) = gamma z         

clear all

%		Facts from US Data


ky=3.2;
iy=.26;
nh=.31;


% Step 1.  Setting up the model 
global theta beta a alpha

% Parameter Values:
     theta=.4;
     delta=iy/ky;
     gamma=.95;
     beta=1/((theta/ky)+1-delta);
     hsol=solve('(1-x)*log(1-x)+x*.6=0');
     h=hsol(2,1);
     a=(1-h)/((1-iy)*.31);
     n=.31/h;
     alpha=0;
	  sigeps=.007;

% Name of return function:
ufunc='divlabretf';	 
	 
ns=4;      % Number of state variables (1,z,k,n-1)
nd=3;      % Number of decision variables (h,i,n)
nsim=50;  % Number of simulations
nobs=220;  % Number of observations per simulation.

hpfilt=hpf(nobs,1600);  % Compute HP filter.

% Compute steady state values of x which will be used to form
%     a quadratic approximation of the return function. 

ys(1,1)=0;
ys(5,1)=h;
ys(3,1)=n;
ys(6,1)=n;
ys(2,1)=((((1-beta*(1-delta))/(beta*theta*h))^(1/(theta-1)))*n);
ys(4,1)=ys(2,1)*delta;


% Define a matrix c containing the laws of motion for all state variables:
%   1'= 1
%   z'= 1 - gamma + gamma * z
%   k'= (1-Delta)*k + i     @

c=zeros(ns,2*ns+nd);
c(1,1)=1;
c(2,2)=gamma;
c(3,3)=1-delta;
c(3,5)=1;
c(4,7)=1;

% Step 2.  Send this information to a function that computes the decision rules.

d=policy(ys,c,ufunc);

% Compute steady states from decision rules and compare
%         with original steady states. 

ssst=[1;0;(-d(1,1)-d(3,1)*d(1,4)+d(3,4)*d(1,1))/(-delta+delta*d(3,4)+d(1,3)-d(1,3)*d(3,4)+d(1,4)*d(3,3));...
   -(delta*d(3,1)+d(1,1)*d(3,3)-d(1,3)*d(3,1))/(-delta+delta*d(3,4)+d(1,3)-d(1,3)*d(3,4)+d(1,4)*d(3,3))];
ss=d*ssst;
ss=[ssst;ss];
disp('Original Steady State: ');;disp(ys)
disp('Steady State from Approximation: ');;disp(ss)
disp('Decision Rules: H and I as functions of 1,z,k,n')
disp(d)

% Step 3.  Simulate the Model

%Calculate parameters of normal distribution.

zm=0;
zs=sigeps;

randn('state',159426)
concor=0;
lag=5;
nm=nobs;
for isim=1:nsim
%    Generate a state matrix.
     r=zeros(nm,1);
     r(5,1)=.007;
     state=ones(nm,4); state(1,2)=0; state(1,3)=ys(2,1);state(1,4)=ys(3,1);
     for iobs=2:nm
          state(iobs,2)=gamma*state(iobs-1,2)+r(iobs,1);
          state(iobs,3)=(d(1,:)*state(iobs-1,:)'+(1-delta)* ...
             state(iobs-1,3));
          state(iobs,4)=d(3,1:3)*state(iobs,1:3)'+d(3,4)*state(iobs-1,4);
     end
  end
  
	 nvars=8;
%    Construct a matrix SIM which contains data from a simulation.
%     Variables are: 1. Output     
%                    2. Consumption
%                    3. Investment 
%                    4. Capital    
%                    5. Employment Rate(n)     
%                    6. Labor Productivity
%							7. Length of Work Shift(h)
%							8. Time Spent Working(nh)

     sim(1:nobs,4)=state(:,3);
     sim(1:nobs,3)=state*d(1,:)';
     sim(1:nobs,7)=state*d(2,:)';
     sim(1:nobs,5)=state*d(3,:)';
     sim(1:nobs,1)=(sim(:,4).^theta).*(sim(:,5).^(1-theta)).*exp(state(:,2))...
        .*sim(:,7);
     sim(1:nobs,2)=sim(:,1)-sim(:,3);
     sim(1:nobs,6)=sim(:,1)./sim(:,5);
     sim(1:nobs,8)=sim(:,5).*sim(:,7);

%    Hit data with filter.

     siml=log(sim);
     simd=hpfilt*siml;


% Steady States to calculate deviation from
time=1:220;
output=ys(5,1)*(ys(2,1)^theta)*ys(3,1)^(1-theta);
cons=output-ys(4,1);

%Deviation From Steady State

outp=100*(sim(:,1)-output)/output;
invst=100*(sim(:,3)-ys(4,1))/ys(4,1);
capt=100*(sim(:,4)-ys(2,1))/ys(2,1);
nh=100*(sim(:,8)-ys(5,1)*ys(3,1))/(ys(5,1)*ys(3,1));

%Graphics

plot(time,100*(sim(:,1)-output)/output ,'k-',time,100*(sim(:,2)-cons)/cons,'--'...
   ,time,100*(sim(:,3)-ys(4,1))/ys(4,1),':',time,100*(sim(:,4)-ys(2,1))/ys(2,1),'.-'...
   ,time,100*(sim(:,7)-ys(5,1))/ys(5,1),'g-',time,100*(sim(:,5)-ys(6,1))/ys(6,1),'y.-')
legend('Output','Consumption','Investment','Capital','Length','Employment')
