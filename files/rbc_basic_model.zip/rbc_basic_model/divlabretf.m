function r=divlabretf(y)
% Procedure that defines the return function, r(z,k,h,i), where
%     y[1,1] = z
%     y[2,1] = k
%     y[3,1] = h
%     y[4,1] = i  
global theta a b
r=log(y(2,1)^theta*(y(1,1)*y(3,1))^(1-theta)-y(4,1))-y(3,1);


