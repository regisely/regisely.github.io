function decis=policy(xs,c,retf)
%This function computes a quadratic approximation and decision rules.
global beta
q=quad(xs,.0001,retf);
[ns,nv]=size(c);
nd=nv-2*ns;
n=ns+nd;

%Solve dynamic program.  

test=10;
v=ones(ns,ns)*(-1000); 
iter=0;
while max((max(test))) > 1E-8
     tv=[q zeros(n,ns); zeros(ns,n) (beta*v)];

%    Reduce out laws of motion for state variables.

     for i=1:ns
          tv=reduce(tv,c(ns-i+1,1:nv-i));
     end

%    Reduce out first order conditions.
     dsave=tv(ns+1:n,1:n);
     for i=1:nd
          d=-tv(n-i+1,1:n-i)./tv(n-i+1,n-i+1);
          if tv(n-i+1,n-i+1)>0, disp('Second order condition fails!');;
             disp(' Decision variable number ');; disp(i);;disp(' at iteration ');; 
			 disp(iter+1)
             disp('Number checked is equal to ');; disp(tv(n-i+1,n-i+1));
          end
          tv=reduce(tv,d);
     end
     test=abs(tv-v); test(1,1)=0;
     v=tv;
     iter=iter+1;
end
disp('Dynamic program required ');; disp(iter);; disp('iterations.')

% Compute decision rules.

decis=-dsave(:,ns+1:n)\dsave(:,1:ns);
