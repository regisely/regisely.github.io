% Sample MATLAB Program to find optimal decision rules for Basic Model
%     The following functional forms are used:
%     U(c,l) = log c + a log l
%     F(k,h) = k^theta * h^(1-theta)
%     A(z) = 1 - rho + rho z         


% Step 1.  Setting up the model 
global theta beta a b

% Parameter Values:
     theta=.36;
     delta=.021;
     rho=.99;
     beta=.99999;
     a=2;
     hzero=0.53;
     b=-a*(log(1-hzero))/hzero;
     sigeps=.018;

% Name of return function:
ufunc='divlabretf';	 
	 
ns=3;      % Number of state variables (1,z,k)
nd=2;      % Number of decision variables (h,i)
nsim=100;  % Number of simulations
nobs=145;  % Number of observations per simulation.

hpfilt=hpf(nobs,1600);  % Compute HP filter.

% Compute steady state values of x which will be used to form
%     a quadratic approximation of the return function. 

disrat=1/beta-1;
ys(1,1)= 1;
ys(3,1)=(1-theta)*(disrat+delta)/((a+1)*(disrat+delta)-theta ...
                  *(disrat+(a+1)*delta));
ys(2,1)=(((disrat+delta)/theta)^(1/(theta-1)))*ys(3,1);
ys(4,1)=ys(2,1)*delta;


% Define a matrix c containing the laws of motion for all state variables:
%   1'= 1
%   z'= 1 - rho + rho * z
%   k'= (1-Delta)*k + i     @

c=zeros(ns,2*ns+nd);
c(1,1)=1;
c(2,1)=1-rho;
c(2,2)=rho;
c(3,3)=1-delta;
c(3,5)=1;

% Step 2.  Send this information to a function that computes the decision rules.

d=policy(ys,c,ufunc);

% Compute steady states from decision rules and compare
%         with original steady states. 

ssst=[1;1;(d(2,1)+d(2,2))/(delta-d(2,3))];
ss=d*ssst;
ss=[ssst;ss];
disp('Original Steady State: ');;disp(ys)
disp('Steady State from Approximation: ');;disp(ss)
disp('Decision Rules: H and I as functions of 1,z,k')
disp(d)

% Step 3.  Simulate the Model

%Calculate parameters of normal distribution.

zm=0.0040;
zs=sigeps;

randn('state',159426)
concor=0;
lag=5;
nm=nobs+100;
for isim=1:nsim
%    Generate a state matrix.
     r=randn(nm,1);
     r=exp(zs*r+zm);
     state=ones(nm,3); state(1,3)=ys(2,1);
     for iobs=2:nm
          state(iobs,2)=1-rho+rho*state(iobs-1,2)*r(iobs,1);
          state(iobs,3)=(d(2,:)*state(iobs-1,:)'+(1-delta)* ...
                         state(iobs-1,3));
     end
     state=state(101:nm,:);
	 nvars=6;
%    Construct a matrix SIM which contains data from a simulation.
%     Variables are: 1. Output     
%                    2. Consumption
%                    3. Investment 
%                    4. Capital    
%                    5. Hours      
%                    6. Labor Productivity

     sim(1:nobs,4)=state(:,3);
     sim(1:nobs,3)=state*d(2,:)';
     sim(1:nobs,5)=state*d(1,:)';
     sim(1:nobs,1)=(sim(:,4).^theta).*(sim(:,5).*state(:,2)).^(1-theta);
     sim(1:nobs,2)=sim(:,1)-sim(:,3);
	 sim(1:nobs,6)=sim(:,1)./sim(:,5);

%    Hit data with filter.

     siml=log(sim);
     simd=hpfilt*siml;

%    Compute statistics from SIMD.

    for nr=1:144
        retur(nr,1) = theta*((state(nr+1,2)*sim(nr+1,5))/sim(nr+1,4))^(1-theta)-delta;
        retfree(nr,1) = (sim(nr+1,2)/(beta*sim(nr,2)))-1;
        prem(nr,1) = retur(nr,1)-retfree(nr,1);
    end
    mretur(isim,:)=mean(retur);
    mretfree(isim,:)=mean(retfree);
    mprem(isim,:)=mean(prem);
    
	 msim(isim,:)=mean(sim);
	 ssimd(isim,:)=std(simd,1)*100;
	 concorn=cov(simd);
	 vsimd = diag(concorn);
	 concorn = concorn./sqrt(vsimd*vsimd');
	 concor(1:6,1:6,isim)=concorn;
     for l=-lag:0
          corlag=cov([simd(1-l:nobs,1) simd(1:nobs+l,:)]);
		  vsimd=diag(corlag);
		  corlag=corlag./sqrt(vsimd*vsimd');
		  corrlag(l+lag+1,:,isim)=corlag(1,2:nvars+1);
          corlag=cov([simd(1:nobs+l,1) simd(1-l:nobs,:)]);
		  vsimd=diag(corlag);
		  corlag=corlag./sqrt(vsimd*vsimd');
		  corrlag(-l+lag+1,:,isim)=corlag(1,2:nvars+1);
     end
end

%Compute summary statistics.
disp('Variables are...')
disp('Output, Consumption, Investment, Capital, Hours, Productivity')
disp('Mean across all simulations')
disp(mean(msim))
disp('Standard Deviations')
disp(mean(ssimd))
disp('Contemporaneous Correlations')
disp(mean(concor,3))
disp('Correlation(Y(t),Variable(t+j))')
disp([[lag:-1:-lag]' mean(corrlag,3)])
disp('Sample Standard Deviations of the Above Statistics:')
disp(' ')
disp('Standard Deviations')
disp(std(ssimd,1))
disp('Contemporaneous Correlations')
disp(std(concor,1,3))
disp('Correlation(Y(t),Variable(t+j))')
disp([[lag:-1:-lag]' std(corrlag,1,3)])

