function rnew=reduce(r,a)
% r is an n x n matrix to be reduced by one row and column
%  a is a vector of parameters of a linear equation x(n)=a*[x(1),..,x(n-1)]
%      used to eliminate the last row and column of r.  
n=length(r);
x=[eye(n-1); a];
rnew=x'*r*x;
