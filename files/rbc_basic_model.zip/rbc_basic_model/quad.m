function q=quad(xs,h,ufunc)
% This procedure calculates a quadratic approximation
%    xs=vector containing steady state values.
%    h=small positive constant
%    u=statement function to be approximated 
n=length(xs);
q=zeros(n+1,n+1);
z=zeros(n,n);
hz=h*ones(n,1);
hz(find(xs))=xs(find(xs))*h;
hz=abs(hz);
z=diag(hz);
for i=1:n
%     if hz(i,1) == 0
%	 	z(i,i)=h; 
%	 end
     q(i+1,i+1)=((feval(ufunc,(xs+z(:,i)))+feval(ufunc,(xs-z(:,i))))./2 ...
	 		-feval(ufunc,xs))/z(i,i).^2;
     for j=1:i
          q(i+1,j+1)=(feval(ufunc,xs+z(:,i)+z(:,j))-feval(ufunc,xs+z(:,i)-z(:,j)) ...
                     -feval(ufunc,xs-z(:,i)+z(:,j))+feval(ufunc,xs-z(:,i)-z(:,j)))/ ...
                     (8*z(i,i)*z(j,j));
          q(j+1,i+1)=q(i+1,j+1);
     end
end
for i=1:n
     q(i+1,1)=(feval(ufunc,xs+z(:,i))-feval(ufunc,xs-z(:,i)))/(2*z(i,i));
     q(i+1,1)=(q(i+1,1)-2*(q(i+1,2:n+1)*xs))/2;
     q(1,i+1)=q(i+1,1);
end
